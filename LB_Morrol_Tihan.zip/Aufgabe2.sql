USE sakila;

alter table actor add birth_year INT(4);

DESC actor;
