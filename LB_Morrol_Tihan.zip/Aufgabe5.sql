USE sakila;

DELETE from film_actor WHERE actor_id = 184;
DELETE from actor WHERE actor_id = 184;