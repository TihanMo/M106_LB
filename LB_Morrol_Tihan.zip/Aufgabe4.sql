USE sakila;

UPDATE actor
SET first_name = 'PETER'
WHERE actor_id = 115;

UPDATE actor
SET last_name = 'WEST'
WHERE actor_id = 115;