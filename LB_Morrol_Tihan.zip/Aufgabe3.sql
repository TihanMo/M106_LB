USE sakila;

INSERT INTO actor (first_name, last_name) VALUES 
('HANS', 'MUSTER');


